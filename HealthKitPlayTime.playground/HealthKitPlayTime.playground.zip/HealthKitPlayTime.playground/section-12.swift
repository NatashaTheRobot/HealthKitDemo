// Find the height in inches for your other minions!
// Find their heigh in other units... try deci-meters



