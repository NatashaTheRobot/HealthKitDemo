// Let's localize Tim's weight to the US system

let massFormatter = MassFormatter()
massFormatter.isForPersonMassUse = true

// Experiment: Change the Unit Style to Short or Medium
massFormatter.unitStyle = .long

let timsLocalizedWeight = massFormatter.string(fromKilograms: minionTim.weightInKG)
// since we're in the U.S., Tim's weight is automatically converted to pounds!

"Minion Tim weights \(timsLocalizedWeight)"

// If needed, you can also just retrieve the localized unit enum and string value!
var massFormatterUnit = MassFormatter.Unit.kilogram
let timsLocalizedWeightUnit = massFormatter.unitString(fromKilograms: minionTim.weightInKG, usedUnit: &massFormatterUnit)
massFormatterUnit == MassFormatter.Unit.pound



// We can do the same thing to localize Tim's height to the U.S. measurement system

let lengthFormatter = LengthFormatter()
lengthFormatter.isForPersonHeightUse = true
lengthFormatter.unitStyle = .short


let timsHeightMeters = timsHeightCM.doubleValue(for: HKUnit.meter())
let timsLocalizedHeight = lengthFormatter.string(fromMeters: timsHeightMeters)

var lengthFormatterUnit = LengthFormatter.Unit.meter
let timsLocalizedHeightUnit = lengthFormatter.unitString(fromMeters: timsHeightMeters, usedUnit: &lengthFormatterUnit)
lengthFormatterUnit == LengthFormatter.Unit.foot

"Minion Tim is \(timsLocalizedHeight) tall"


