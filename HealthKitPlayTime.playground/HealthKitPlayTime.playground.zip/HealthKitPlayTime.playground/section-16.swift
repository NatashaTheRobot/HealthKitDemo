let kg = HKUnit(from: "kg")

timsHeightCM.is(compatibleWith: kg)
// cm are not compatible with kg

let dm = HKUnit(from: "dm")

var timsHeightDM: Double?
if timsHeightCM.is(compatibleWith: dm) {
    timsHeightDM = timsHeightCM.doubleValue(for: dm)
}

if let timsHeightDM = timsHeightDM {
    print("Tim's height in deci-meters is \(timsHeightDM) \n")
} else {
    print("Tim's height cannot be calculated in deci-meters! \n")
}


