// Uncomment the code below to see what happens when you try to convert incompatible units

//let gramUnit = HKUnit.gramUnit()
//let timsHeightGrams = timsHeightCM.doubleValueForUnit(gramUnit)


