let kgUnit = HKUnit(from: "kg")

let timsWeightKG = HKQuantity(unit: kgUnit, doubleValue: minionTim.weightInKG)

let ounceUnit = HKUnit.ounce()

var timsWeightOunces: Double?
if timsWeightKG.is(compatibleWith: ounceUnit) {
    timsWeightOunces = timsWeightKG.doubleValue(for: ounceUnit)
}

if let timsWeightOunces = timsWeightOunces {
    print("Tim's weight in ounces is \(timsWeightOunces) \n")
} else {
    print("Error: Tim's weight is not convertable to ounces! \n")
}

// Do the same as above for Stones! How many stones does Tim weight? What about your other minions?











