let timsHeightInches = timsHeightCM.doubleValue(for: inchUnit)
// You can now see that Tim's height is 47 Inches!


