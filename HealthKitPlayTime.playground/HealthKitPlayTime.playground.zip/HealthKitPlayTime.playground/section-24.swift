// Uncomment the code below to see Minion Tim's weight and height in Burmese.
// Try out other locales from this list: https://gist.github.com/jacobbubu/1836273


//extension NSLocale {
//    class func currentLocale() -> NSLocale {
//        return NSLocale(localeIdentifier: "my_MM")
//    }
//}





